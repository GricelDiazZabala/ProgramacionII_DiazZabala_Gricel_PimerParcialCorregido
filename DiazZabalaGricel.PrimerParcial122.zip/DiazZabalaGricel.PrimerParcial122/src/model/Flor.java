package model;

public class Flor extends Planta implements Aromatico {

    private TemporadaFlorecimiento temporada;

    public Flor(TemporadaFlorecimiento temporada, String nombre, String ubicacion, String mejorClima) {
        super(nombre, ubicacion, mejorClima);
        this.temporada = temporada;
    }

    @Override
    public void desprenderAroma() {
        System.out.println("Soy una flor y tengo rico aroma");
    }

    public TemporadaFlorecimiento getTemporada() {
        return temporada;
    }

    @Override
    public String toString() {
        return "Flor{" + "temporada=" + temporada + '}';
    }

}
