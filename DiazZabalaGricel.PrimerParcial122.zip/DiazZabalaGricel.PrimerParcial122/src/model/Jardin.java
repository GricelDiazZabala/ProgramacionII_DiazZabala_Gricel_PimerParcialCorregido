package model;

import exceptions.PlantaRepetidaException;
import java.util.ArrayList;
import java.util.List;

public class Jardin {

    private String nombre;
    private List<Planta> plantas;

    public Jardin(String nombre) {
        this.nombre = nombre;
        plantas = new ArrayList<>();
    }

    //chequeemos que no vayamos a anadir objetos nulos
    private void checkNull(Planta p) {
        if (p == null) {
            throw new NullPointerException("Objeto nulo");
        }
    }

    // siendo que no es nulo, se agrega la planta pero lanza plantaRepetidaException si ya esta registrada
    public void agregarPlanta(Planta planta) {
        checkNull(planta);
        if (plantas.contains(planta)) {
            throw new PlantaRepetidaException("Ya existe una planta con el nombre" + planta.getNombre() + " en la ubicacion " + planta.getUbicacion());
        }
        plantas.add(planta);
        System.out.println("Planta agregada: " + planta.getNombre());
    }

    // recorre la lista de plantas y las muestra
    public void mostrarPlantas() {
        if (plantas.isEmpty()) {
            System.out.println("No hay plantas para mostrar");
        } else {
            System.out.println("Lista de plantas:");
            for (Planta p : plantas) {
                System.out.println(p);
            }
        }
    }

    //poda solo las plantas podables y avisa si es no podable
    public void podarPlantas() {
        for (Planta planta : plantas) {
            if (planta instanceof Podable) {
                ((Podable) planta).podar();
            } else {
                System.out.println("La planta " + planta.getNombre() + " no puede ser podada.");
            }
        }
    }

    // solo las flores tienen temporada de florecimiento, este metodo  hace un arraylist para filtrar las flores por temporada
    // si la planta es una flor, obtiene la temporada en la que florece y las clasifica
    public List<Flor> filtrarPorTemporadaFlorecimiento(TemporadaFlorecimiento temporada) {

        List<Flor> floresFiltradas = new ArrayList<>();
        for (Planta planta : plantas) {
            if (planta instanceof Flor) {
                Flor flor = (Flor) planta;
                if (flor.getTemporada() == temporada) {
                    floresFiltradas.add(flor);
                    System.out.println("Flor: " + flor.getNombre()
                            + ", Ubicacion: " + planta.getUbicacion()
                            + ", Clima: " + planta.getMejorClima()
                            + ", Temporada: " + flor.getTemporada());
                }
            }
        }

        return floresFiltradas;
    }
}
