package model;

public interface Podable {

    void podar();
}
