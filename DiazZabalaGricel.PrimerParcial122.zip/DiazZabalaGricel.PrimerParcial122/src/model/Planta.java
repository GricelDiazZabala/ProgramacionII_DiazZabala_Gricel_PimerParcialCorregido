package model;

import java.util.Objects;

public abstract class Planta {

    private String nombre;
    private String ubicacion;
    private String mejorClima;

    public Planta(String nombre, String ubicacion, String mejorClima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.mejorClima = mejorClima;
    }

    public String getNombre() {
        return nombre;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Planta p)) {
            return false;
        }
        return nombre.equals(p.nombre) && ubicacion.equals(p.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", ubicacion=" + ubicacion + ", mejorClima=" + mejorClima;
    }
    
    

}
