package model;

import java.util.Objects;

public abstract class Planta {

    private String nombre;
    private String ubicacion;
    private String mejorClima;

    public Planta(String nombre, String ubicacion, String mejorClima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.mejorClima = mejorClima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getMejorClima() {
        return mejorClima;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Planta planta = (Planta) o;
        return nombre.equals(planta.nombre) && ubicacion.equals(planta.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

}
