package model;

public class Arbol extends Planta implements Podable, Aromatico {

    private int alturaMax;

    public Arbol(int alturaMax, String nombre, String ubicacion, String mejorClima) {
        super(nombre, ubicacion, mejorClima);
        this.alturaMax = alturaMax;
    }
    @Override
    public void podar() {
        System.out.println("Soy %s y me estan podando".formatted(getNombre()));
    }
    @Override
    public void desprenderAroma() {
        System.out.println("Hola, %s y desprendo aroma".formatted(getNombre()));
    }

    @Override
    public String toString() {
        return "Arbol: "+ super.toString() + "alturaMax=" + alturaMax + 'm';
    }

}
