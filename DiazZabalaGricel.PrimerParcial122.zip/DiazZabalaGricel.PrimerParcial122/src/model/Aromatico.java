package model;

public interface Aromatico {

    void desprenderAroma();
}
