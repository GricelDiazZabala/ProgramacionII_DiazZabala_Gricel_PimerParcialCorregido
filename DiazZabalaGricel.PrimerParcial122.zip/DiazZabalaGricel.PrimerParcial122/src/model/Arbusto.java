package model;

public class Arbusto extends Planta implements Podable {

    private int densidadFollaje;
    private static final int DENSIDAD_MIN = 1;
    private static final int DENSIDAD_MAX = 10;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String mejorClima) {
        super(nombre, ubicacion, mejorClima);
        validarDensidad(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }

    @Override
    public void podar() {
        System.out.println("Soy %s y me estan podando".formatted(getNombre()));
    }

    private void validarDensidad(int densidadFollaje) {
        if (densidadFollaje < DENSIDAD_MIN || densidadFollaje > DENSIDAD_MAX) {
            throw new IllegalArgumentException("Densidad invalida");
        }
    }

    @Override
    public String toString() {
        return "Arbusto: " + super.toString() + "densidadFollaje=" + densidadFollaje;
    }

}
