package Main;

import exceptions.PlantaRepetidaException;
import model.Arbol;
import model.Arbusto;
import model.Flor;
import model.Jardin;
import model.Planta;
import model.TemporadaFlorecimiento;

public class Main {

    public static void main(String[] args) {

        Jardin j1 = new Jardin("Isla Bonita");

        Arbol r1 = new Arbol(10, "Roble", "zona norte", "frio");
        Arbol r2 = new Arbol(10, "Roble", "zona norte", "frio");

        Flor f1 = new Flor(TemporadaFlorecimiento.PRIMAVERA, "Jazmin", "centro", "calido");

        Arbusto a1 = new Arbusto(8, "Rododendro", "esquinas", "templado");

        try {
            j1.agregarPlanta(r1);
            j1.agregarPlanta(r2); // lanza excepción
        } catch (PlantaRepetidaException e) {
            System.out.println("Error al agregar planta: " + e.getMessage());
        }

        j1.agregarPlanta(f1);
        j1.agregarPlanta(a1);

        j1.mostrarPlantas();

        j1.podarPlantas();

        j1.filtrarPorTemporadaFlorecimiento(TemporadaFlorecimiento.PRIMAVERA);
    }

}
