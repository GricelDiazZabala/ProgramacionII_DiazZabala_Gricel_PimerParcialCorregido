package exceptions;

import model.Planta;

public class PlantaRepetidaException extends RuntimeException {

    private static final String MENSAJE = "";

    public PlantaRepetidaException() {
    }

    public PlantaRepetidaException(String MENSAJE) {
        super(MENSAJE);
    }
}
